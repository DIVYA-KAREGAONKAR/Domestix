// src/services/profileService.ts
import api from "./api"; // 👈 make sure you already have api.ts with axios config

// Get worker profile
export const getWorkerProfile = async () => {
  const res = await api.get("/worker/profile/");
  return res.data; // your backend returns { success, data: {...} }
};

// Update worker profile
export const updateWorkerProfile = async (data: any) => {
  const res = await api.put("/worker/profile/", data);
  return res.data;
};
