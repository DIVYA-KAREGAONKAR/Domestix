import api from './api';

//  Register new user
export async function registerUser(userData) {
  return api.post('/register/', {
    username: userData.email,
    email: userData.email,
    password: userData.password,
    password2: userData.password, // required by Django serializer
    first_name: userData.first_name,
    last_name: userData.last_name,
    phone: userData.phone,
    is_worker: true,
    is_employer: false,
  });
}


export const loginUser = async (username, password) => {
  const response = await fetch('/api/token/', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ username, password }),
  });

  let data;

  try {
    data = await response.json();
  } catch (err) {
    throw new Error("Invalid response from server (not JSON)");
  }

  if (!response.ok) {
    throw new Error(data?.detail || 'Login failed');
  }

  if (!data.user) {
    throw new Error("No user info received");
  }

  return data;
};





//  Get logged-in user's profile
export async function getUserProfile() {
  return api.get('/profile/');  // e.g. your /profile endpoint
}

//  Logout user — optional, just clear localStorage
export function logoutUser() {
  localStorage.removeItem('access_token');
  localStorage.removeItem('refresh_token'); // optional if using refresh
}
