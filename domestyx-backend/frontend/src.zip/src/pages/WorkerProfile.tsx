import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";
import { getWorkerProfile, updateWorkerProfile } from "@/services/profileService";

import {
  User,
  MapPin,
  Upload,
  Save,
  ArrowLeft,
  Star,
  Calendar,
  DollarSign,
} from "lucide-react";

const WorkerProfile = () => {
  const { user, isAuthenticated, isWorker } = useAuth();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);

  const [profileData, setProfileData] = useState({
    firstName: user?.first_name || "",
    lastName: user?.last_name || "",
    email: user?.email || "",
    phone: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
    bio: "",
    hourlyRate: "",
    experience: "",
    availability: [] as string[],
    services: [] as string[],
    languages: [] as string[],
    hasTransportation: false,
    hasReferences: false,
    isBackgroundChecked: false,
  });

  // Options
  const serviceOptions = [
    "House Cleaning",
    "Babysitting",
    "Elder Care",
    "Pet Care",
    "Cooking",
    "Laundry",
    "Gardening",
    "Personal Assistant",
    "Tutoring",
    "Event Help",
  ];

  const availabilityOptions = [
    "Monday - Morning",
    "Monday - Afternoon",
    "Monday - Evening",
    "Tuesday - Morning",
    "Tuesday - Afternoon",
    "Tuesday - Evening",
    "Wednesday - Morning",
    "Wednesday - Afternoon",
    "Wednesday - Evening",
    "Thursday - Morning",
    "Thursday - Afternoon",
    "Thursday - Evening",
    "Friday - Morning",
    "Friday - Afternoon",
    "Friday - Evening",
    "Saturday - Morning",
    "Saturday - Afternoon",
    "Saturday - Evening",
    "Sunday - Morning",
    "Sunday - Afternoon",
    "Sunday - Evening",
  ];

  const languageOptions = [
    "English",
    "Spanish",
    "French",
    "Chinese",
    "Arabic",
    "Portuguese",
    "Russian",
    "German",
    "Italian",
    "Hindi",
  ];

  // 🔹 Load profile on mount
  useEffect(() => {
    if (!isAuthenticated || !isWorker) {
      navigate("/worker/login");
    } else {
      loadProfile();
    }
  }, [isAuthenticated, isWorker, navigate]);

  const loadProfile = async () => {
    try {
      const res = await getWorkerProfile();
      if (res.success) {
        setProfileData(res.data); // ✅ Only use profile data
      }
    } catch (err) {
      toast({ title: "Error", description: "Failed to load profile" });
    }
  };

  // 🔹 Handle inputs
  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setProfileData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // 🔹 Handle checkbox arrays
  const handleCheckboxChange = (
    category: "services" | "availability" | "languages",
    value: string
  ) => {
    setProfileData((prev) => ({
      ...prev,
      [category]: prev[category].includes(value)
        ? prev[category].filter((item) => item !== value)
        : [...prev[category], value],
    }));
  };

  // 🔹 Save profile
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const res = await updateWorkerProfile(profileData);
      if (res.success) {
        setProfileData(res.data);
        toast({ title: "Success", description: "Profile updated!" });
      }
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to update profile",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-app-bg">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Link
                to="/worker/dashboard"
                className="flex items-center text-primary hover:text-primary/80"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Link>
              <span className="text-gray-300">|</span>
              <span className="text-gray-600">Worker Profile</span>
            </div>
          </div>
        </div>
      </header>

      {/* Form */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-app-text mb-2">
            Worker Profile
          </h1>
          <p className="text-gray-600">
            Complete your profile to attract more employers
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* --- Personal Info --- */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <User className="h-5 w-5 mr-2" />
                Personal Information
              </CardTitle>
              <CardDescription>
                Your basic personal details and contact information
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-6">
                <Avatar className="h-24 w-24">
                  <AvatarImage src="/placeholder-avatar.jpg" />
                  <AvatarFallback className="bg-primary text-white text-2xl">
                    {user.first_name.charAt(0)}
                    {user.last_name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <Button variant="outline" size="sm">
                    <Upload className="h-4 w-4 mr-2" />
                    Upload Photo
                  </Button>
                  <p className="text-sm text-gray-500 mt-2">
                    A professional photo increases your chances of getting hired
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName">First Name</Label>
                  <Input
                    id="firstName"
                    name="firstName"
                    value={profileData.firstName}
                    onChange={handleInputChange}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input
                    id="lastName"
                    name="lastName"
                    value={profileData.lastName}
                    onChange={handleInputChange}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={profileData.email}
                    disabled
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    name="phone"
                    type="tel"
                    value={profileData.phone}
                    onChange={handleInputChange}
                    className="mt-1"
                    placeholder="+1 (555) 123-4567"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* --- Address --- */}
          {/* keep your address, professional info, services, availability, languages etc. sections as you had */}

          {/* Submit */}
          <div className="flex justify-end space-x-4">
            <Link to="/worker/dashboard">
              <Button variant="outline">Cancel</Button>
            </Link>
            <Button type="submit" className="btn-primary" disabled={isLoading}>
              <Save className="h-4 w-4 mr-2" />
              {isLoading ? "Saving..." : "Save Profile"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default WorkerProfile;
